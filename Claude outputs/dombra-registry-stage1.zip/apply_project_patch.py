"""
Правит config/settings.py и config/urls.py проекта на месте (повторный запуск безопасен).
Запуск: python3 apply_project_patch.py <папка проекта>
Совместим с Python 3.10+.
"""

import re
import sys
from pathlib import Path

project = Path(sys.argv[1])
settings_path = project / "config" / "settings.py"
urls_path = project / "config" / "urls.py"

# ---------------- settings.py ----------------
text = settings_path.read_text(encoding="utf-8")
original = text

if not re.search(r"^\s*['\"]registry['\"],", text, flags=re.M):
    text, count = re.subn(
        r"(^\s*)(['\"])django\.contrib\.staticfiles\2,\n",
        lambda m: m.group(0) + f"{m.group(1)}{m.group(2)}registry{m.group(2)},\n",
        text,
        count=1,
        flags=re.M,
    )
    assert count == 1, "не найден django.contrib.staticfiles в INSTALLED_APPS"

text, count = re.subn(r"^LANGUAGE_CODE = .*$", "LANGUAGE_CODE = 'ru'", text, count=1, flags=re.M)
assert count == 1, "не найден LANGUAGE_CODE"
text, count = re.subn(r"^TIME_ZONE = .*$", "TIME_ZONE = 'Asia/Almaty'", text, count=1, flags=re.M)
assert count == 1, "не найден TIME_ZONE"

if "MEDIA_ROOT" not in text:
    text = text.rstrip("\n") + """


# Загружаемые файлы реестра: фотографии, аудиозаписи, сертификаты

MEDIA_URL = 'media/'
MEDIA_ROOT = BASE_DIR / 'media'


# Реестр домбр

REGISTRY_NUMBER_PREFIX = 'DOM-KZ'  # формат номера: DOM-KZ-2026-000001
REGISTRY_MAX_UPLOAD_MB = 200       # предельный размер одного загружаемого файла
"""

if text != original:
    settings_path.write_text(text, encoding="utf-8")
    print("settings.py: обновлён")
else:
    print("settings.py: изменений не требуется")

# ---------------- urls.py ----------------
text = urls_path.read_text(encoding="utf-8")
original = text

if "MEDIA_ROOT" not in text:
    old_block = re.search(
        r"from django\.contrib import admin\nfrom django\.urls import path\n\nurlpatterns = \[\n\s*path\((['\"])admin/\1, admin\.site\.urls\),\n\]\n",
        text,
    )
    assert old_block, "urls.py отличается от стандартного, правьте вручную"
    new_block = """from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path
from django.views.generic import RedirectView

urlpatterns = [
    # Пока публичной страницы нет, корень сайта ведёт в панель администратора.
    path('', RedirectView.as_view(pattern_name='admin:index'), name='home'),
    path('admin/', admin.site.urls),
]

if settings.DEBUG:
    # В режиме разработки загруженные файлы отдаёт сам Django.
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
"""
    text = text[: old_block.start()] + new_block + text[old_block.end():]

if text != original:
    urls_path.write_text(text, encoding="utf-8")
    print("urls.py: обновлён")
else:
    print("urls.py: изменений не требуется")
